<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class Products extends Controller
{
    public function postProduct( Request $request){
        $product = Product::create($request->all('name', 'price', 'stock'));
        return $Product;
    }
    public function getProduct(Request $request){
        $product = Product::get($request->all);
        return $product;
    }

    public function PutProduct(Resquest $request){
        $product =Product::findorfail($request->id);
        $product->update(
            ['name'->$request->name],
            [ 'description'->$request->description]);
    }

    public function deleteProduct(Request $request){
        $product ->delete('id');
        return $product;
    }
}
