<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class Categories extends Controller
{
    public function postCategory( Request $request){
        $category = Category::create($request->all('name', 'description'));
        return $category;
    }
    public function getCategory(Request $request){
        $category = Category::get($request->all);
        return $category;
    }

    public function PutCategory(Resquest $request){
        $category =Category::findorfail($request->id);
        $category->update(
            ['name'->$request->name],
            [ 'description'->$request->description]);
    }

    public function deleteCategory(Request $request){
        $category ->delete('id');
        return $category;
    }
}
